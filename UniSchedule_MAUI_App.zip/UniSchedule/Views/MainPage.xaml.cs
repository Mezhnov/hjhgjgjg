using UniSchedule.ViewModels;

namespace UniSchedule.Views;

public partial class MainPage : ContentPage
{
    public MainPage(ScheduleViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
