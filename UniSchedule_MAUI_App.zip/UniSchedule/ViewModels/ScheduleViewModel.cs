using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using UniSchedule.Models;
using UniSchedule.Services;

namespace UniSchedule.ViewModels;

public partial class ScheduleViewModel : ObservableObject
{
    private readonly ScheduleService _scheduleService;
    
    [ObservableProperty]
    private ObservableCollection<DaySchedule> weekSchedule = new();
    
    [ObservableProperty]
    private ObservableCollection<Group> groups = new();
    
    [ObservableProperty]
    private Group? selectedGroup;
    
    [ObservableProperty]
    private int currentWeek = 6; // Текущая неделя (февраль 2026)
    
    [ObservableProperty]
    private string weekDatesText = string.Empty;
    
    [ObservableProperty]
    private string userInitials = "АС";
    
    public ScheduleViewModel(ScheduleService scheduleService)
    {
        _scheduleService = scheduleService;
        LoadGroups();
        LoadSchedule();
    }
    
    private void LoadGroups()
    {
        var groupList = _scheduleService.GetGroups();
        Groups = new ObservableCollection<Group>(groupList);
        SelectedGroup = Groups.FirstOrDefault();
    }
    
    private void LoadSchedule()
    {
        if (SelectedGroup == null) return;
        
        var (weekStart, weekEnd) = _scheduleService.GetWeekDates(CurrentWeek);
        var schedule = _scheduleService.GetWeekSchedule(SelectedGroup.Id, weekStart);
        
        WeekSchedule = new ObservableCollection<DaySchedule>(schedule);
        
        var culture = new System.Globalization.CultureInfo("ru-RU");
        WeekDatesText = $"{weekStart:d MMMM} - {weekEnd:d MMMM yyyy}";
    }
    
    [RelayCommand]
    private void PreviousWeek()
    {
        if (CurrentWeek > 1)
        {
            CurrentWeek--;
            LoadSchedule();
        }
    }
    
    [RelayCommand]
    private void NextWeek()
    {
        if (CurrentWeek < 20)
        {
            CurrentWeek++;
            LoadSchedule();
        }
    }
    
    [RelayCommand]
    private void ToggleDay(DaySchedule day)
    {
        day.IsExpanded = !day.IsExpanded;
    }
    
    [RelayCommand]
    private void GroupChanged()
    {
        LoadSchedule();
    }
    
    partial void OnSelectedGroupChanged(Group? value)
    {
        LoadSchedule();
    }
}
