using UniSchedule.Models;

namespace UniSchedule.Services;

public class ScheduleService
{
    private readonly Dictionary<string, Dictionary<DayOfWeek, List<Lesson>>> _scheduleData;
    
    public ScheduleService()
    {
        _scheduleData = InitializeScheduleData();
    }
    
    public List<Group> GetGroups()
    {
        return new List<Group>
        {
            new() { Id = "1", Name = "ИС-3-24" },
            new() { Id = "2", Name = "ИС-3-23" },
            new() { Id = "3", Name = "ПИ-2-24" },
            new() { Id = "4", Name = "ПИ-1-24" }
        };
    }
    
    public List<DaySchedule> GetWeekSchedule(string groupId, DateTime weekStart)
    {
        var schedule = new List<DaySchedule>();
        var dayNames = new[] { "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье" };
        
        for (int i = 0; i < 7; i++)
        {
            var date = weekStart.AddDays(i);
            var dayOfWeek = (DayOfWeek)(i == 6 ? 0 : i + 1);
            
            var daySchedule = new DaySchedule
            {
                DayName = dayNames[i],
                Date = date,
                Lessons = GetLessonsForDay(groupId, dayOfWeek),
                IsExpanded = date.Date == DateTime.Today
            };
            
            schedule.Add(daySchedule);
        }
        
        return schedule;
    }
    
    private List<Lesson> GetLessonsForDay(string groupId, DayOfWeek day)
    {
        if (_scheduleData.TryGetValue(groupId, out var groupSchedule))
        {
            if (groupSchedule.TryGetValue(day, out var lessons))
            {
                return lessons;
            }
        }
        return new List<Lesson>();
    }
    
    public (DateTime Start, DateTime End) GetWeekDates(int weekNumber, int year = 2026)
    {
        // Базовая дата - 26 января 2026 (неделя 5)
        var baseDate = new DateTime(year, 1, 26);
        var weekStart = baseDate.AddDays((weekNumber - 5) * 7);
        var weekEnd = weekStart.AddDays(6);
        return (weekStart, weekEnd);
    }
    
    private Dictionary<string, Dictionary<DayOfWeek, List<Lesson>>> InitializeScheduleData()
    {
        var data = new Dictionary<string, Dictionary<DayOfWeek, List<Lesson>>>();
        
        // Расписание для группы ИС-3-24
        data["1"] = new Dictionary<DayOfWeek, List<Lesson>>
        {
            [DayOfWeek.Monday] = new List<Lesson>
            {
                new() { Name = "Математический анализ", Teacher = "Иванов А.П.", Room = "305", 
                       StartTime = new TimeSpan(9, 0, 0), EndTime = new TimeSpan(10, 30, 0), Type = LessonType.Lecture },
                new() { Name = "Программирование на Python", Teacher = "Петрова М.С.", Room = "412",
                       StartTime = new TimeSpan(10, 45, 0), EndTime = new TimeSpan(12, 15, 0), Type = LessonType.Practice },
                new() { Name = "Базы данных", Teacher = "Сидоров К.В.", Room = "201",
                       StartTime = new TimeSpan(13, 0, 0), EndTime = new TimeSpan(14, 30, 0), Type = LessonType.Lab }
            },
            [DayOfWeek.Tuesday] = new List<Lesson>
            {
                new() { Name = "Физика", Teacher = "Козлов Д.И.", Room = "108",
                       StartTime = new TimeSpan(9, 0, 0), EndTime = new TimeSpan(10, 30, 0), Type = LessonType.Lecture },
                new() { Name = "Иностранный язык", Teacher = "Смирнова Е.А.", Room = "220",
                       StartTime = new TimeSpan(10, 45, 0), EndTime = new TimeSpan(12, 15, 0), Type = LessonType.Seminar }
            },
            [DayOfWeek.Wednesday] = new List<Lesson>
            {
                new() { Name = "Веб-разработка", Teacher = "Николаев П.Р.", Room = "415",
                       StartTime = new TimeSpan(10, 45, 0), EndTime = new TimeSpan(12, 15, 0), Type = LessonType.Lab },
                new() { Name = "Алгоритмы и структуры данных", Teacher = "Федоров А.М.", Room = "302",
                       StartTime = new TimeSpan(13, 0, 0), EndTime = new TimeSpan(14, 30, 0), Type = LessonType.Lecture },
                new() { Name = "Дискретная математика", Teacher = "Волков И.С.", Room = "305",
                       StartTime = new TimeSpan(14, 45, 0), EndTime = new TimeSpan(16, 15, 0), Type = LessonType.Practice }
            },
            [DayOfWeek.Thursday] = new List<Lesson>
            {
                new() { Name = "Операционные системы", Teacher = "Кузнецов В.В.", Room = "410",
                       StartTime = new TimeSpan(9, 0, 0), EndTime = new TimeSpan(10, 30, 0), Type = LessonType.Lecture },
                new() { Name = "Компьютерные сети", Teacher = "Морозов С.П.", Room = "208",
                       StartTime = new TimeSpan(10, 45, 0), EndTime = new TimeSpan(12, 15, 0), Type = LessonType.Lab }
            },
            [DayOfWeek.Friday] = new List<Lesson>
            {
                new() { Name = "Математический анализ", Teacher = "Иванов А.П.", Room = "305",
                       StartTime = new TimeSpan(9, 0, 0), EndTime = new TimeSpan(10, 30, 0), Type = LessonType.Seminar },
                new() { Name = "Физическая культура", Teacher = "Соколов Р.А.", Room = "Спортзал",
                       StartTime = new TimeSpan(13, 0, 0), EndTime = new TimeSpan(14, 30, 0), Type = LessonType.Practice }
            },
            [DayOfWeek.Saturday] = new List<Lesson>(),
            [DayOfWeek.Sunday] = new List<Lesson>()
        };
        
        // Копируем расписание для других групп с небольшими изменениями
        data["2"] = data["1"];
        data["3"] = data["1"];
        data["4"] = data["1"];
        
        return data;
    }
}
