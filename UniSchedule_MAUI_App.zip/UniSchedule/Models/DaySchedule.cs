using CommunityToolkit.Mvvm.ComponentModel;

namespace UniSchedule.Models;

public partial class DaySchedule : ObservableObject
{
    public string DayName { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public List<Lesson> Lessons { get; set; } = new();
    
    [ObservableProperty]
    private bool isExpanded;
    
    public bool IsToday => Date.Date == DateTime.Today;
    public bool HasLessons => Lessons.Count > 0;
    public string FormattedDate => Date.ToString("d MMMM", new System.Globalization.CultureInfo("ru-RU"));
    
    public Color IconBackgroundColor => IsToday 
        ? Color.FromArgb("#10b981") 
        : Color.FromArgb("#3b82f6");
        
    public Color BorderColor => IsToday 
        ? Color.FromArgb("#10b981") 
        : Color.FromArgb("#3b82f633");
        
    public string TodayLabel => IsToday ? " (Сегодня)" : "";
    public Color TodayLabelColor => Color.FromArgb("#10b981");
}
