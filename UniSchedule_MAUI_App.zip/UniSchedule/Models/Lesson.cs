namespace UniSchedule.Models;

public class Lesson
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; } = string.Empty;
    public string Teacher { get; set; } = string.Empty;
    public string Room { get; set; } = string.Empty;
    public TimeSpan StartTime { get; set; }
    public TimeSpan EndTime { get; set; }
    public LessonType Type { get; set; }
    
    public string StartTimeFormatted => StartTime.ToString(@"hh\:mm");
    public string EndTimeFormatted => EndTime.ToString(@"hh\:mm");
    public string TypeName => Type switch
    {
        LessonType.Lecture => "Лекция",
        LessonType.Practice => "Практика",
        LessonType.Lab => "Лаб. работа",
        LessonType.Seminar => "Семинар",
        _ => "Занятие"
    };
    
    public Color TypeBackgroundColor => Type switch
    {
        LessonType.Lecture => Color.FromArgb("#3b82f633"),
        LessonType.Practice => Color.FromArgb("#10b98133"),
        LessonType.Lab => Color.FromArgb("#a855f733"),
        LessonType.Seminar => Color.FromArgb("#fbbf2433"),
        _ => Color.FromArgb("#3b82f633")
    };
    
    public Color TypeTextColor => Type switch
    {
        LessonType.Lecture => Color.FromArgb("#60a5fa"),
        LessonType.Practice => Color.FromArgb("#34d399"),
        LessonType.Lab => Color.FromArgb("#c084fc"),
        LessonType.Seminar => Color.FromArgb("#fbbf24"),
        _ => Color.FromArgb("#60a5fa")
    };
}

public enum LessonType
{
    Lecture,
    Practice,
    Lab,
    Seminar
}
