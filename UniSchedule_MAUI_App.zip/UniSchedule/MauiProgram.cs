using CommunityToolkit.Maui;
using Microsoft.Extensions.Logging;

namespace UniSchedule;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .UseMauiCommunityToolkit()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("Inter-Regular.ttf", "InterRegular");
                fonts.AddFont("Inter-Bold.ttf", "InterBold");
                fonts.AddFont("Inter-SemiBold.ttf", "InterSemiBold");
            });

        // Регистрация сервисов
        builder.Services.AddSingleton<Services.ScheduleService>();
        builder.Services.AddSingleton<ViewModels.ScheduleViewModel>();
        builder.Services.AddSingleton<Views.MainPage>();

#if DEBUG
        builder.Logging.AddDebug();
#endif

        return builder.Build();
    }
}
