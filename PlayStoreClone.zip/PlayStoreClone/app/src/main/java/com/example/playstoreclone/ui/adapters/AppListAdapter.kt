package com.example.playstoreclone.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.playstoreclone.R
import com.example.playstoreclone.models.App

class AppListAdapter(
    private val apps: List<App>,
    private val onAppClick: (App) -> Unit
) : RecyclerView.Adapter<AppListAdapter.AppListViewHolder>() {

    inner class AppListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvPosition: TextView = itemView.findViewById(R.id.tvPosition)
        private val ivAppIcon: ImageView = itemView.findViewById(R.id.ivAppIcon)
        private val tvAppName: TextView = itemView.findViewById(R.id.tvAppName)
        private val tvCategory: TextView = itemView.findViewById(R.id.tvCategory)
        private val tvRating: TextView = itemView.findViewById(R.id.tvRating)
        private val tvSize: TextView = itemView.findViewById(R.id.tvSize)

        fun bind(app: App, position: Int) {
            tvPosition.text = (position + 1).toString()
            tvAppName.text = app.name
            tvCategory.text = app.category
            tvRating.text = app.rating.toString()
            tvSize.text = app.size
            
            itemView.setOnClickListener { onAppClick(app) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppListViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_list, parent, false)
        return AppListViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppListViewHolder, position: Int) {
        holder.bind(apps[position], position)
    }

    override fun getItemCount(): Int = apps.size
}
