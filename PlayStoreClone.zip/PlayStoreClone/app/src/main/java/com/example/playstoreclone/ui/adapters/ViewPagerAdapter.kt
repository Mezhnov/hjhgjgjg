package com.example.playstoreclone.ui.adapters

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.playstoreclone.ui.fragments.HomeFragment

class ViewPagerAdapter(
    fragmentActivity: FragmentActivity,
    private val tabs: List<String>
) : FragmentStateAdapter(fragmentActivity) {

    override fun getItemCount(): Int = tabs.size

    override fun createFragment(position: Int): Fragment {
        return HomeFragment.newInstance(tabs[position])
    }
}
