package com.example.playstoreclone.models

data class App(
    val id: String,
    val name: String,
    val developer: String,
    val iconUrl: String,
    val rating: Float,
    val reviewsCount: String,
    val downloads: String,
    val size: String,
    val category: String,
    val description: String,
    val screenshots: List<String> = emptyList(),
    val isInstalled: Boolean = false,
    val containsAds: Boolean = false,
    val hasInAppPurchases: Boolean = false,
    val ageRating: String = "3+"
)
