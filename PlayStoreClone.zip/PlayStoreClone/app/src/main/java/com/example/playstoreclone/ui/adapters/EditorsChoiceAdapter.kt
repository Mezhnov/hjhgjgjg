package com.example.playstoreclone.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.playstoreclone.R
import com.example.playstoreclone.models.App

class EditorsChoiceAdapter(
    private val apps: List<App>,
    private val onAppClick: (App) -> Unit
) : RecyclerView.Adapter<EditorsChoiceAdapter.EditorsChoiceViewHolder>() {

    inner class EditorsChoiceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivFeaturedImage: ImageView = itemView.findViewById(R.id.ivFeaturedImage)
        private val ivAppIcon: ImageView = itemView.findViewById(R.id.ivAppIcon)
        private val tvAppName: TextView = itemView.findViewById(R.id.tvAppName)
        private val tvCategory: TextView = itemView.findViewById(R.id.tvCategory)
        private val tvRating: TextView = itemView.findViewById(R.id.tvRating)

        fun bind(app: App) {
            tvAppName.text = app.name
            tvCategory.text = app.category
            tvRating.text = app.rating.toString()
            
            // Glide.with(itemView.context).load(app.iconUrl).into(ivAppIcon)
            
            itemView.setOnClickListener { onAppClick(app) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EditorsChoiceViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_editors_choice, parent, false)
        return EditorsChoiceViewHolder(view)
    }

    override fun onBindViewHolder(holder: EditorsChoiceViewHolder, position: Int) {
        holder.bind(apps[position])
    }

    override fun getItemCount(): Int = apps.size
}
