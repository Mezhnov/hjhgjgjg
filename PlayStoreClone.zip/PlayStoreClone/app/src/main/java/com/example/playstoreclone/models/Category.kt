package com.example.playstoreclone.models

import androidx.annotation.DrawableRes

data class Category(
    val id: String,
    val name: String,
    @DrawableRes val iconRes: Int,
    val color: Int
)
