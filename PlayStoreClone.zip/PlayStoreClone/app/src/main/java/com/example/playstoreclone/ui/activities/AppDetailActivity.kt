package com.example.playstoreclone.ui.activities

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.playstoreclone.R
import com.example.playstoreclone.models.App
import com.example.playstoreclone.ui.adapters.AppCardAdapter
import com.example.playstoreclone.ui.adapters.ScreenshotAdapter

class AppDetailActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var ivAppIcon: ImageView
    private lateinit var tvAppName: TextView
    private lateinit var tvDeveloper: TextView
    private lateinit var tvRating: TextView
    private lateinit var tvDownloads: TextView
    private lateinit var tvSize: TextView
    private lateinit var tvDescription: TextView
    private lateinit var btnInstall: Button
    private lateinit var rvScreenshots: RecyclerView
    private lateinit var rvSimilarApps: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_detail)

        initViews()
        setupToolbar()
        loadAppDetails()
        setupScreenshots()
        setupSimilarApps()
    }

    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        ivAppIcon = findViewById(R.id.ivAppIcon)
        tvAppName = findViewById(R.id.tvAppName)
        tvDeveloper = findViewById(R.id.tvDeveloper)
        tvRating = findViewById(R.id.tvRating)
        tvDownloads = findViewById(R.id.tvDownloads)
        tvSize = findViewById(R.id.tvSize)
        tvDescription = findViewById(R.id.tvDescription)
        btnInstall = findViewById(R.id.btnInstall)
        rvScreenshots = findViewById(R.id.rvScreenshots)
        rvSimilarApps = findViewById(R.id.rvSimilarApps)
    }

    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { onBackPressed() }
    }

    private fun loadAppDetails() {
        // Загрузка данных приложения (демо данные)
        tvAppName.text = "Приложение"
        tvDeveloper.text = "Developer Inc."
        tvRating.text = "4.5"
        tvDownloads.text = "100M+"
        tvSize.text = "150 MB"
        tvDescription.text = "Описание приложения с подробной информацией о функциях и возможностях."

        btnInstall.setOnClickListener {
            Toast.makeText(this, "Установка началась...", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupScreenshots() {
        rvScreenshots.layoutManager = LinearLayoutManager(
            this, 
            LinearLayoutManager.HORIZONTAL, 
            false
        )
        
        val screenshots = listOf(
            "screenshot1.png",
            "screenshot2.png",
            "screenshot3.png",
            "screenshot4.png"
        )
        
        rvScreenshots.adapter = ScreenshotAdapter(screenshots) { position ->
            // Открыть полноэкранный просмотр скриншота
            Toast.makeText(this, "Скриншот $position", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupSimilarApps() {
        rvSimilarApps.layoutManager = LinearLayoutManager(
            this, 
            LinearLayoutManager.HORIZONTAL, 
            false
        )
        
        val similarApps = getDemoApps()
        rvSimilarApps.adapter = AppCardAdapter(similarApps) { app ->
            // Открыть страницу приложения
        }
    }

    private fun getDemoApps(): List<App> {
        return listOf(
            App(
                id = "1",
                name = "Приложение 1",
                developer = "Developer",
                iconUrl = "",
                rating = 4.5f,
                reviewsCount = "1M",
                downloads = "10M+",
                size = "50 MB",
                category = "Игры",
                description = "Описание"
            ),
            App(
                id = "2",
                name = "Приложение 2",
                developer = "Developer",
                iconUrl = "",
                rating = 4.3f,
                reviewsCount = "500K",
                downloads = "5M+",
                size = "80 MB",
                category = "Приложения",
                description = "Описание"
            )
        )
    }
}
