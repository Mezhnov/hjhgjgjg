package com.example.playstoreclone.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.playstoreclone.R

class ScreenshotAdapter(
    private val screenshots: List<String>,
    private val onScreenshotClick: (Int) -> Unit
) : RecyclerView.Adapter<ScreenshotAdapter.ScreenshotViewHolder>() {

    inner class ScreenshotViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivScreenshot: ImageView = itemView.findViewById(R.id.ivScreenshot)

        fun bind(screenshotUrl: String, position: Int) {
            // Glide.with(itemView.context).load(screenshotUrl).into(ivScreenshot)
            
            itemView.setOnClickListener { onScreenshotClick(position) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScreenshotViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_screenshot, parent, false)
        return ScreenshotViewHolder(view)
    }

    override fun onBindViewHolder(holder: ScreenshotViewHolder, position: Int) {
        holder.bind(screenshots[position], position)
    }

    override fun getItemCount(): Int = screenshots.size
}
