package com.example.playstoreclone.models

data class Banner(
    val id: String,
    val title: String,
    val subtitle: String,
    val imageUrl: String,
    val appId: String,
    val appIconUrl: String
)
