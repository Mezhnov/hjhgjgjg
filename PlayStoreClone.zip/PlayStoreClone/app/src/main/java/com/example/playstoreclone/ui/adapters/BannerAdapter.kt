package com.example.playstoreclone.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.playstoreclone.R
import com.example.playstoreclone.models.Banner

class BannerAdapter(
    private val banners: List<Banner>,
    private val onBannerClick: (Banner) -> Unit,
    private val onInstallClick: (Banner) -> Unit
) : RecyclerView.Adapter<BannerAdapter.BannerViewHolder>() {

    inner class BannerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivBannerImage: ImageView = itemView.findViewById(R.id.ivBannerImage)
        private val ivAppIcon: ImageView = itemView.findViewById(R.id.ivAppIcon)
        private val tvAppName: TextView = itemView.findViewById(R.id.tvAppName)
        private val tvAppDesc: TextView = itemView.findViewById(R.id.tvAppDesc)
        private val btnInstall: Button = itemView.findViewById(R.id.btnInstall)

        fun bind(banner: Banner) {
            tvAppName.text = banner.title
            tvAppDesc.text = banner.subtitle
            
            // Glide.with(itemView.context).load(banner.imageUrl).into(ivBannerImage)
            // Glide.with(itemView.context).load(banner.appIconUrl).into(ivAppIcon)
            
            itemView.setOnClickListener { onBannerClick(banner) }
            btnInstall.setOnClickListener { onInstallClick(banner) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BannerViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_banner, parent, false)
        return BannerViewHolder(view)
    }

    override fun onBindViewHolder(holder: BannerViewHolder, position: Int) {
        holder.bind(banners[position])
    }

    override fun getItemCount(): Int = banners.size
}
