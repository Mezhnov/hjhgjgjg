package com.example.playstoreclone.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.example.playstoreclone.R
import com.example.playstoreclone.models.App
import com.example.playstoreclone.models.Banner
import com.example.playstoreclone.models.Category
import com.example.playstoreclone.ui.activities.AppDetailActivity
import com.example.playstoreclone.ui.adapters.*
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class HomeFragment : Fragment() {

    private lateinit var bannerViewPager: ViewPager2
    private lateinit var bannerIndicator: TabLayout

    companion object {
        private const val ARG_TAB_NAME = "tab_name"

        fun newInstance(tabName: String): HomeFragment {
            return HomeFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_TAB_NAME, tabName)
                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupBannerCarousel(view)
        setupRecommendedSection(view)
        setupCategoriesSection(view)
        setupTopChartsSection(view)
        setupEditorsChoiceSection(view)
        setupNewReleasesSection(view)
    }

    private fun setupBannerCarousel(view: View) {
        bannerViewPager = view.findViewById(R.id.bannerViewPager)
        bannerIndicator = view.findViewById(R.id.bannerIndicator)

        val banners = getDemoBanners()
        bannerViewPager.adapter = BannerAdapter(
            banners,
            onBannerClick = { banner ->
                openAppDetail()
            },
            onInstallClick = { banner ->
                // Установить приложение
            }
        )

        TabLayoutMediator(bannerIndicator, bannerViewPager) { _, _ -> }.attach()
        
        // Добавляем отступы для эффекта карусели
        bannerViewPager.offscreenPageLimit = 3
        bannerViewPager.setPageTransformer(CarouselPageTransformer())
    }

    private fun setupRecommendedSection(view: View) {
        val section = view.findViewById<View>(R.id.sectionRecommended)
        section.findViewById<TextView>(R.id.tvSectionTitle).text = "Рекомендуем"
        
        val recyclerView = section.findViewById<RecyclerView>(R.id.rvApps)
        recyclerView.layoutManager = LinearLayoutManager(
            requireContext(),
            LinearLayoutManager.HORIZONTAL,
            false
        )
        recyclerView.adapter = AppCardAdapter(getDemoApps()) { app ->
            openAppDetail()
        }
    }

    private fun setupCategoriesSection(view: View) {
        val section = view.findViewById<View>(R.id.sectionCategories)
        val recyclerView = section.findViewById<RecyclerView>(R.id.rvCategories)
        
        recyclerView.layoutManager = LinearLayoutManager(
            requireContext(),
            LinearLayoutManager.HORIZONTAL,
            false
        )
        recyclerView.adapter = CategoryAdapter(getDemoCategories()) { category ->
            // Открыть категорию
        }
    }

    private fun setupTopChartsSection(view: View) {
        val section = view.findViewById<View>(R.id.sectionTopCharts)
        section.findViewById<TextView>(R.id.tvSectionTitle).text = "Топ чартов"
        
        val recyclerView = section.findViewById<RecyclerView>(R.id.rvApps)
        recyclerView.layoutManager = LinearLayoutManager(
            requireContext(),
            LinearLayoutManager.HORIZONTAL,
            false
        )
        recyclerView.adapter = AppCardAdapter(getDemoApps()) { app ->
            openAppDetail()
        }
    }

    private fun setupEditorsChoiceSection(view: View) {
        val section = view.findViewById<View>(R.id.sectionEditorsChoice)
        val recyclerView = section.findViewById<RecyclerView>(R.id.rvEditorsChoice)
        
        recyclerView.layoutManager = LinearLayoutManager(
            requireContext(),
            LinearLayoutManager.HORIZONTAL,
            false
        )
        recyclerView.adapter = EditorsChoiceAdapter(getDemoApps()) { app ->
            openAppDetail()
        }
    }

    private fun setupNewReleasesSection(view: View) {
        val section = view.findViewById<View>(R.id.sectionNewReleases)
        section.findViewById<TextView>(R.id.tvSectionTitle).text = "Новинки"
        
        val recyclerView = section.findViewById<RecyclerView>(R.id.rvApps)
        recyclerView.layoutManager = LinearLayoutManager(
            requireContext(),
            LinearLayoutManager.HORIZONTAL,
            false
        )
        recyclerView.adapter = AppCardAdapter(getDemoApps()) { app ->
            openAppDetail()
        }
    }

    private fun openAppDetail() {
        startActivity(Intent(requireContext(), AppDetailActivity::class.java))
    }

    // Демо данные
    private fun getDemoBanners(): List<Banner> {
        return listOf(
            Banner("1", "Новая игра", "Скачай бесплатно", "", "1", ""),
            Banner("2", "Топ приложение", "Установи сейчас", "", "2", ""),
            Banner("3", "Выбор редакции", "Лучшее приложение месяца", "", "3", "")
        )
    }

    private fun getDemoApps(): List<App> {
        return listOf(
            App("1", "Telegram", "Telegram FZ-LLC", "", 4.5f, "15M", "1B+", "50 MB", "Общение", ""),
            App("2", "Instagram", "Meta Platforms", "", 4.3f, "120M", "5B+", "200 MB", "Соцсети", ""),
            App("3", "TikTok", "TikTok Pte. Ltd.", "", 4.4f, "50M", "2B+", "150 MB", "Видео", ""),
            App("4", "WhatsApp", "WhatsApp LLC", "", 4.2f, "180M", "5B+", "60 MB", "Общение", ""),
            App("5", "YouTube", "Google LLC", "", 4.3f, "200M", "10B+", "120 MB", "Видео", "")
        )
    }

    private fun getDemoCategories(): List<Category> {
        return listOf(
            Category("1", "Экшен", R.drawable.ic_games, 0),
            Category("2", "Аркады", R.drawable.ic_games, 0),
            Category("3", "Головоломки", R.drawable.ic_games, 0),
            Category("4", "Гонки", R.drawable.ic_games, 0),
            Category("5", "Стратегии", R.drawable.ic_games, 0)
        )
    }

    // Трансформер для карусели баннеров
    inner class CarouselPageTransformer : ViewPager2.PageTransformer {
        override fun transformPage(page: View, position: Float) {
            val absPosition = kotlin.math.abs(position)
            page.scaleY = 1 - (0.1f * absPosition)
            page.alpha = 1 - (0.3f * absPosition)
        }
    }
}
