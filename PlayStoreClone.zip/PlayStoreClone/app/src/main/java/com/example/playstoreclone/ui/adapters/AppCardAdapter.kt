package com.example.playstoreclone.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.playstoreclone.R
import com.example.playstoreclone.models.App

class AppCardAdapter(
    private val apps: List<App>,
    private val onAppClick: (App) -> Unit
) : RecyclerView.Adapter<AppCardAdapter.AppViewHolder>() {

    inner class AppViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivAppIcon: ImageView = itemView.findViewById(R.id.ivAppIcon)
        private val tvAppName: TextView = itemView.findViewById(R.id.tvAppName)
        private val tvRating: TextView = itemView.findViewById(R.id.tvRating)
        private val tvSize: TextView = itemView.findViewById(R.id.tvSize)

        fun bind(app: App) {
            tvAppName.text = app.name
            tvRating.text = app.rating.toString()
            tvSize.text = app.size
            
            // Здесь можно использовать Glide/Coil для загрузки изображений
            // Glide.with(itemView.context).load(app.iconUrl).into(ivAppIcon)
            
            itemView.setOnClickListener { onAppClick(app) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_card, parent, false)
        return AppViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(apps[position])
    }

    override fun getItemCount(): Int = apps.size
}
