package com.example.playstoreclone.ui.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.example.playstoreclone.R
import com.example.playstoreclone.ui.adapters.ViewPagerAdapter
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {

    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout
    private lateinit var bottomNavigation: BottomNavigationView

    private val gameTabs = listOf("Для вас", "Топ чартов", "Дети", "Премиум", "Категории")
    private val appTabs = listOf("Для вас", "Топ чартов", "Дети", "Категории")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupViewPager()
        setupBottomNavigation()
    }

    private fun initViews() {
        viewPager = findViewById(R.id.viewPager)
        tabLayout = findViewById(R.id.tabLayout)
        bottomNavigation = findViewById(R.id.bottomNavigation)
    }

    private fun setupViewPager() {
        val adapter = ViewPagerAdapter(this, gameTabs)
        viewPager.adapter = adapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = gameTabs[position]
        }.attach()
    }

    private fun setupBottomNavigation() {
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_games -> {
                    updateTabs(gameTabs)
                    true
                }
                R.id.nav_apps -> {
                    updateTabs(appTabs)
                    true
                }
                R.id.nav_movies -> {
                    updateTabs(listOf("Для вас", "Топ продаж", "Новинки"))
                    true
                }
                R.id.nav_books -> {
                    updateTabs(listOf("Для вас", "Топ продаж", "Новинки", "Жанры"))
                    true
                }
                else -> false
            }
        }
    }

    private fun updateTabs(tabs: List<String>) {
        val adapter = ViewPagerAdapter(this, tabs)
        viewPager.adapter = adapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = tabs[position]
        }.attach()
    }
}
